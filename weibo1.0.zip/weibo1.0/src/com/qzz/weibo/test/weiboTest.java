package com.qzz.weibo.test;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.qzz.weibo.dao.W_UserInfoDao;
import com.qzz.weibo.dao.W_collectDao;
import com.qzz.weibo.dao.W_usersDao;
import com.qzz.weibo.dao.W_weiboDao;
import com.qzz.weibo.entity.W_userinfo;
import com.qzz.weibo.entity.W_users;
import com.qzz.weibo.entity.W_weibo;
import com.qzz.weibo.service.W_weiboService;
import com.qzz.weibo.util.BaseDao;

public class weiboTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
//		W_weiboService ws = new W_weiboService();
//
//		List<W_weibo> list = ws.queryMyWb();
//		System.out.println(list.size());
//		for (W_weibo w_weibo : list) {
//			System.out.println(list);
//		}		
		
//		String nickname ="��������";
//		List<W_weibo>  list1 = new ArrayList<>();
//		W_collectDao W_collectDao = new W_collectDao();
//		list1= W_collectDao.queryMyColl(nickname);
//		for (W_weibo W_weibo : list1) {
//			System.out.println(W_weibo);
//		}
		
//		W_UserInfoDao wif = new W_UserInfoDao();
//		int i = Integer.parseInt(wif.isExisNickname("��������"));
//		System.out.println(i>1);
		W_usersDao ws = new W_usersDao();
		boolean f=ws.userRegister("haha", "000000", "������");
		System.out.println(f);
	}

}
