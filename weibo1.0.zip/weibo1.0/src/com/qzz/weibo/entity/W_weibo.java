package com.qzz.weibo.entity;

/**
 * ΢��ʵ����
 * @author Administrator
 *
 */
public class W_weibo {
	private int WEIBOID;//΢�����
	private String FWDCONTENT;//ת��ʱ��һ��΢��������
	private String CONTENT;//΢�����ݣ�ת��ʱ���������
	private String SENDNAME;//�������ǳ�
	private String IMAGE;//΢����ͼ
	private String PUBLISHTIME;//����ʱ��
	private int COMMENTNUM;//������
	private int ZANNUM;//������
	private int FORWARDNUM;//ת����
	private int TYPEID;//΢������
	private String ISFORWORD;//�Ƿ�Ϊת��
	private int FWDWEIBOID;	//��һ����΢�����
	private int COLLECTNUM;//�ղ���
	private String TOUXIANG;//������ͷ��
	private String FORWARDIMG;//ԭ����ͼƬ��ת��Դ��
	private String OLDTIME;//ԭ����ת��Դ���ķ���ʱ��
	private String OLDNAME;//ԭ����ת��Դ���ķ������ǳ�
	private int BASEID;
	
	public int getCOLLECTNUM() {
		return COLLECTNUM;
	}
	public void setCOLLECTNUM(int cOLLECTNUM) {
		COLLECTNUM = cOLLECTNUM;
	}
	public int getWEIBOID() {
		return WEIBOID;
	}
	public void setWEIBOID(int wEIBOID) {
		WEIBOID = wEIBOID;
	}
	public String getFWDCONTENT() {
		return FWDCONTENT;
	}
	public void setFWDCONTENT(String fWDCONTENT) {
		FWDCONTENT = fWDCONTENT;
	}
	public String getCONTENT() {
		return CONTENT;
	}
	public void setCONTENT(String cONTENT) {
		CONTENT = cONTENT;
	}
	public String getSENDNAME() {
		return SENDNAME;
	}
	public void setSENDNAME(String sENDNAME) {
		SENDNAME = sENDNAME;
	}
	public String getIMAGE() {
		return IMAGE;
	}
	public void setIMAGE(String iMAGE) {
		IMAGE = iMAGE;
	}
	public String getPUBLISHTIME() {
		return PUBLISHTIME;
	}
	public void setPUBLISHTIME(String pUBLISHTIME) {
		PUBLISHTIME = pUBLISHTIME;
	}
	public int getCOMMENTNUM() {
		return COMMENTNUM;
	}
	public void setCOMMENTNUM(int cOMMENTNUM) {
		COMMENTNUM = cOMMENTNUM;
	}
	public int getZANNUM() {
		return ZANNUM;
	}
	public void setZANNUM(int zANNUM) {
		ZANNUM = zANNUM;
	}
	public int getFORWARDNUM() {
		return FORWARDNUM;
	}
	public void setFORWARDNUM(int fORWARDNUM) {
		FORWARDNUM = fORWARDNUM;
	}
	public int getTYPEID() {
		return TYPEID;
	}
	public void setTYPEID(int tYPEID) {
		TYPEID = tYPEID;
	}
	public String getISFORWORD() {
		return ISFORWORD;
	}
	public void setISFORWORD(String iSFORWORD) {
		ISFORWORD = iSFORWORD;
	}
	public int getFWDWEIBOID() {
		return FWDWEIBOID;
	}
	public void setFWDWEIBOID(int fWDWEIBOID) {
		FWDWEIBOID = fWDWEIBOID;
	}
	
	public String getTOUXIANG() {
		return TOUXIANG;
	}
	public void setTOUXIANG(String tOUXIANG) {
		TOUXIANG = tOUXIANG;
	}
	
	public String getFORWARDIMG() {
		return FORWARDIMG;
	}
	public void setFORWARDIMG(String fORWARDIMG) {
		FORWARDIMG = fORWARDIMG;
	}
	public String getOLDTIME() {
		return OLDTIME;
	}
	public void setOLDTIME(String oLDTIME) {
		OLDTIME = oLDTIME;
	}
	
	public String getOLDNAME() {
		return OLDNAME;
	}
	public void setOLDNAME(String oLDNAME) {
		OLDNAME = oLDNAME;
	}
	
	public int getBASEID() {
		return BASEID;
	}
	public void setBASEID(int bASEID) {
		BASEID = bASEID;
	}
	public W_weibo(int wEIBOID, String fWDCONTENT, String cONTENT, String sENDNAME, String iMAGE, String pUBLISHTIME,
			int cOMMENTNUM, int zANNUM, int fORWARDNUM, int tYPEID, String iSFORWORD, int fWDWEIBOID, int cOLLECTNUM,
			String tOUXIANG, String fORWARDIMG, String oLDTIME, String oLDNAME, int bASEID) {
		super();
		WEIBOID = wEIBOID;
		FWDCONTENT = fWDCONTENT;
		CONTENT = cONTENT;
		SENDNAME = sENDNAME;
		IMAGE = iMAGE;
		PUBLISHTIME = pUBLISHTIME;
		COMMENTNUM = cOMMENTNUM;
		ZANNUM = zANNUM;
		FORWARDNUM = fORWARDNUM;
		TYPEID = tYPEID;
		ISFORWORD = iSFORWORD;
		FWDWEIBOID = fWDWEIBOID;
		COLLECTNUM = cOLLECTNUM;
		TOUXIANG = tOUXIANG;
		FORWARDIMG = fORWARDIMG;
		OLDTIME = oLDTIME;
		OLDNAME = oLDNAME;
		BASEID = bASEID;
	}
	@Override
	public String toString() {
		return "W_weibo [WEIBOID=" + WEIBOID + ", FWDCONTENT=" + FWDCONTENT + ", CONTENT=" + CONTENT + ", SENDNAME="
				+ SENDNAME + ", IMAGE=" + IMAGE + ", PUBLISHTIME=" + PUBLISHTIME + ", COMMENTNUM=" + COMMENTNUM
				+ ", ZANNUM=" + ZANNUM + ", FORWARDNUM=" + FORWARDNUM + ", TYPEID=" + TYPEID + ", ISFORWORD="
				+ ISFORWORD + ", FWDWEIBOID=" + FWDWEIBOID + ", COLLECTNUM=" + COLLECTNUM + ", TOUXIANG=" + TOUXIANG
				+ ", FORWARDIMG=" + FORWARDIMG + ", OLDTIME=" + OLDTIME + ", OLDNAME=" + OLDNAME + ", BASEID=" + BASEID
				+ "]";
	}
	public W_weibo() {
		// TODO Auto-generated constructor stub
	}
}
