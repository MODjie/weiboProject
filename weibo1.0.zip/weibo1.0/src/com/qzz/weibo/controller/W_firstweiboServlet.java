package com.qzz.weibo.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.qzz.weibo.entity.W_comment;
import com.qzz.weibo.entity.W_reply;
import com.qzz.weibo.entity.W_weibo;
import com.qzz.weibo.service.W_commentService;
import com.qzz.weibo.service.W_replyService;
import com.qzz.weibo.service.W_weiboService;

/**
 * Servlet implementation class WeiBoServlet
 */
@WebServlet("/firstWeiBoServlet")
public class W_firstweiboServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	W_weiboService  ws=new W_weiboService();
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public W_firstweiboServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
		String path = request.getScheme() + "://" + request.getServerName() + ":" + request.getLocalPort()
				+ request.getContextPath() + "/";
		

		response.setCharacterEncoding("utf-8");
		request.setCharacterEncoding("utf-8");
	
		List<W_weibo> list = new ArrayList<>();
		List<W_comment> list2 = new ArrayList<>();
		List<W_reply> replyList = new ArrayList<>();
		HttpSession session = request.getSession();
			String xra=request.getParameter("xra");	
            if(xra.equals("byall")) {
            	/* �Ȼ�ȡ΢�������º�����΢��,ֻ��ʾ����*/
            	List<W_weibo>pdfreshall=new ArrayList<>();
            	List<W_weibo>pdhotdoorall=new ArrayList<>();
            	List<W_weibo>pdfresh=new ArrayList<>();
            	List<W_weibo>pdhotdoor=new ArrayList<>();
            	int page=1;
				int pageSize=5;
				pdfreshall=ws.queryWebBytype(8);
				pdhotdoorall=ws.queryWebBytype(2);
				if(pdfreshall.size()>5) {
					pdfresh=pdfreshall.subList(0, 4);
				}else {
					pdfresh=pdfreshall.subList(0, pdfreshall.size());
				}
				if(pdhotdoorall.size()>5) {
					pdhotdoor=pdhotdoorall.subList(0, 4);
				}else {
					pdhotdoor=pdfreshall.subList(0, pdhotdoorall.size());
				}
				
	
            	request.setAttribute("pdfresh", pdfresh);
            	request.setAttribute("pdhotdoor", pdhotdoor);
            	request.getRequestDispatcher("vistormain.jsp").forward(request, response);
				return;	
			}else if(xra.equals("hotdoor")){
				/* ��ȡ����΢��*/
				list=ws.queryWebBytype(2);				
				request.setAttribute("list", list);		
				request.getRequestDispatcher("vistorhotdoor.jsp").forward(request, response);
				return;				
			}else if(xra.equals("vsatr")){
				/* ��ȡ����΢��*/
				list=ws.queryWebBytype(3);
				request.setAttribute("list", list);
				request.getRequestDispatcher("vistorstar.jsp").forward(request, response);
				return;		
			}else if(xra.equals("vtop")) {
				/* ��ȡͷ��΢��*/
			    list=ws.queryWebBytype(4);	
				request.setAttribute("list", list);
				request.getRequestDispatcher("vistortop.jsp").forward(request, response);
				return;		
			}else if(xra.equals("vfresh")) {
				/* ��ȡ������΢��*/
				list=ws.queryWebBytype(8);
				request.setAttribute("list", list);		
				request.getRequestDispatcher("vistorfresh.jsp").forward(request, response);
				return;		
			}
			else if(xra.equals("vlove")) {
				/* ��ȡ���΢��*/
				list=ws.queryWebBytype(4);
				request.setAttribute("list", list);			
				request.getRequestDispatcher("vistorlove.jsp").forward(request, response);
				return;		
			}else if(xra.equals("xmoreweibo")) {
				int weiboid= Integer.parseInt(request.getParameter("conid"));
				int typeid= Integer.parseInt(request.getParameter("contypeid"));
				W_commentService wcs = new W_commentService();
				
				list = ws.queryWbById(weiboid);
				
				W_weibo detailWb = list.get(0);
				// ��ȡ����΢����������������
				list2 = wcs.queryCmById(weiboid);
				// �õ������۵����лظ�����replyList��
				replyList = new W_replyService().queryAllReply();
				request.setAttribute("replyList", replyList);
				request.setAttribute("list2", list2);
				request.setAttribute("detailWb", detailWb);
				request.getRequestDispatcher("more.jsp").forward(request, response);
			}
		
	
	}
}

