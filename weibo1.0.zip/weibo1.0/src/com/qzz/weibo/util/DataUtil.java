package com.qzz.weibo.util;

/**
   update
*/
public class DataUtil {
	public static String imgname;
	public static String number;
}
